!/bin/csh
latex $1
#bibtex $1
#%bibtex $1
#%%latex $1
#%%bibtex $1
#%%latex $1
dvips -o $1.ps $1.dvi
dvipdf -sPAPERSIZE=a4 $1.dvi $1.pdf 
rm -f $1.log $1.dvi $1.ps $1.aux $1.snm $1.toc $1.out $1.nav
#dvipdf -Spapersize=a4 $1
#ggv $1.ps &

